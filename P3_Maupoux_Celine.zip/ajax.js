/*Fichier de gestion des requetes et fonctions d'apres les donnees temps réel de l'API JC DECAUX */






